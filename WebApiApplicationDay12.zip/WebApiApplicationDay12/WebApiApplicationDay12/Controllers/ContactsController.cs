﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.UI.WebControls;
using WebApiApplicationDay12.Models;


namespace WebApiApplicationDay12.Controllers
{
    public class ContactsController : ApiController
    {
  
        private int _nextId = 1;

     
        static readonly List<Contact> Contacts=new List<Contact>()
        {

         new Contact {ContactId = 1,Address = "strada Palat ,Iasi",City = "Iasi",Name = "Marta",Email = "x@test.com"},
       new Contact  {ContactId = 2,Address = "strada Fericirii ,Iasi",City = "Iasi",Name = "Viorel",Email = "viorel@test.com"},
       new Contact  {ContactId = 3,Address = "strada A1 ,Bucuresti",City = "Bucuresti",Name = "George",Email = "george@test.com",}
     };
        [HttpGet]
        public IEnumerable<Contact> GetAllContacts()
        {
            return Contacts;
        }
        [HttpGet]
        public Contact GetContactById(int id)
        {
            var query = Contacts.SingleOrDefault((x) => x.ContactId == id);
            if (Contacts == null)
            {
                //return NotFound();
            }
            return query;
        }

        [HttpPost]
        public void Create([FromBody]Contact contact)
        {
            Contacts.Add(contact);

        }


        [HttpDelete]

        public Contact DeleteById(int contactId)
        {
            var query = Contacts.SingleOrDefault((x) => x.ContactId == contactId);
            return query;
        }

        [HttpPut]
        public bool Update([FromUri]Contact item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = Contacts.FindIndex(p => p.ContactId == item.ContactId);
            if (index == -1)
            {
                return false;
            }

            Contacts.RemoveAt(index);
            Contacts.Add(item);
            return true;
        }

    }


}
