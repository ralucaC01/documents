﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using WebApiApplicationDay12.Models;

namespace WebApiApplicationDay12
{
    public class ContactRepository:IContactRepository
    {
        private List<Contact> contacts;
        private int _nextId =1;

        public ContactRepository()
        {


        }
        [HttpGet]
        public IEnumerable<Contact> GetAll()
        {
            return contacts;
        }
        [HttpGet]
        public Contact Get(int id)
        {
            return contacts.Find(p => p.ContactId == id);

        }

        [HttpPost]
        public Contact Add(Contact item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.ContactId = item.ContactId++;
            contacts.Add(item);
            return item;
        }
        [HttpDelete]
        public void Remove(int id)
        {
            contacts.RemoveAll(x => x.ContactId == id);
        }
        [HttpPut]
        public bool Update(Contact item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            int index = contacts.FindIndex(p => p.ContactId == item.ContactId);
            if (index == -1)
            {
                return false;
            }

            contacts.RemoveAt(index);
            contacts.Add(item);
            return true;
        }

    }
}