﻿using System;
using System.Collections.Generic;
using System.Drawing.Design;
using System.Linq;
using System.Web;
using WebApiApplicationDay12.Models;

namespace WebApiApplicationDay12
{
    public class ContactsFactory
    {
        public static IContactRepository Initialize()
        {


            return new ContactRepository();
            {
             List<Contact> Contact1 = new List<Contact>()
        {

         new Contact {ContactId = 1,Address = "strada Palat ,Iasi",City = "Iasi",Name = "Marta",Email = "x@test.com"},
       new Contact  {ContactId = 2,Address = "strada Fericirii ,Iasi",City = "Iasi",Name = "Viorel",Email = "viorel@test.com"},
       new Contact  {ContactId = 3,Address = "strada A1 ,Bucuresti",City = "Bucuresti",Name = "George",Email = "george@test.com",}
     };


            }
        }
    }
}